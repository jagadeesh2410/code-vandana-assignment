function submitForm() {
    var firstName = document.getElementById("firstName").value;
    var lastName = document.getElementById("lastName").value;
    var dob = document.getElementById("dob").value;
    var country = document.getElementById("country").value;
    var genderElements = document.getElementsByName("gender");
    var gender = "";
    for (var i = 0; i < genderElements.length; i++) {
        if (genderElements[i].checked) {
            gender = genderElements[i].value;
        }
    }
    var profession = document.getElementById("profession").value;
    var email = document.getElementById("email").value;
    var mobileNumber = document.getElementById("mobileNumber").value;

    if (firstName && lastName && dob && country && gender && profession && email && mobileNumber) {
        document.getElementById("popupFirstName").textContent = firstName;
        document.getElementById("popupLastName").textContent = lastName;
        document.getElementById("popupDob").textContent = dob;
        document.getElementById("popupCountry").textContent = country;
        document.getElementById("popupGender").textContent = gender;
        document.getElementById("popupProfession").textContent = profession;
        document.getElementById("popupEmail").textContent = email;
        document.getElementById("popupMobileNumber").textContent = mobileNumber;
        document.getElementById("popup").style.display = "block";
    } else {
        alert("Please fill out all required fields.");
    }
}

function resetForm() {
    document.getElementById("surveyForm").reset();
}

function closePopup() {
    document.getElementById("popup").style.display = "none";
    resetForm();
}
