const arr = [1,6,9,4,2,10];

arr.sort(function(a, b) {
    return b - a;
});

console.log(arr); 
